#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "ennemi.h"
#include "perso.h"

int main() {
    SDL_Surface *screen = NULL;
       Uint32 dt,t_prev;
       int col_down=0;
       int col_arrow,collision,collision2,col_boss;
    SDL_Init(SDL_INIT_VIDEO);
    screen = SDL_SetVideoMode(800, 600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (screen == NULL) {
        printf("Unable to set video mode: %s\n", SDL_GetError());
        return 1;
    }

    // Initialize SDL_mixer for sound effects
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        printf("SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError());
        return 1;
    }

    // Initialize random seed
    srand(time(NULL));

    // Initialize enemies
    ennemi enemy1, enemy2;
    initEnnemi(&enemy1, &enemy2);

    // Initialize boss
    boss alien;
    initboss(&alien);
int touche_state=0;
    // Initialize player character
    Personne player;
    initPerso(&player);
    int posinit,sec_jump;
    posinit=player.pos.pos_Perso.y;  
        t_prev=SDL_GetTicks();

    // Main game loop
    int quit = 0;
    while (!quit) {
        // Handle events
        SDL_Event event;
        while(SDL_PollEvent(&event)){
        switch(event.type)
       {
        case SDL_QUIT:
        quit=1;
        break;
    //****
        case SDL_KEYDOWN:
            {
               
                if(!touche_state)
                 {
                 if(event.key.keysym.sym==SDLK_RIGHT && player.up!=2 && player.up!=3)
                {
                    player.img.direction=0;
     
            
                }
                 if(event.key.keysym.sym==SDLK_RIGHT && (player.up==2 || player.up==3))
                {
                    player.img.direction=0;
                        }
                else if(event.key.keysym.sym==SDLK_LEFT  && player.up!=2 && player.up!=3)
                {
                    player.img.direction=1;
                    
                }
                else if(event.key.keysym.sym==SDLK_LEFT  && (player.up==2 || player.up==3))
                {
                    player.img.direction=1;
                }
                else if(event.key.keysym.sym==SDLK_UP  )
                {
                    player.img.direction=2;
                    player.up=1;
                    sec_jump=1;
                    saut(&player,dt,posinit,sec_jump,col_down);
                                      
                }
                else if(event.key.keysym.sym==SDLK_DOWN)
                {
                    player.img.direction=3;
                }
            }
                else
                {
                     if(event.key.keysym.sym==SDLK_d && player.up!=2 && player.up!=3)
                {
                    player.img.direction=0;
              
                }
                 if(event.key.keysym.sym==SDLK_d && (player.up==2 || player.up==3))
                {
                    player.img.direction=0;
               
                }
                else if(event.key.keysym.sym==SDLK_q  && player.up!=2 && player.up!=3)
                {
                    player.img.direction=1;
                 
                }
                else if(event.key.keysym.sym==SDLK_q && (player.up==2 || player.up==3))
                {
                    player.img.direction=1;
                }
                else if(event.key.keysym.sym==SDLK_z  )
                {
                    player.img.direction=2;
                    player.up=1;
                    sec_jump=1;
                    saut(&player,dt,posinit,sec_jump,col_down);
                 
                    
                }
                else if(event.key.keysym.sym==SDLK_s)
                {
                    player.img.direction=3;
                }
                }
                if(event.key.keysym.sym==SDLK_SPACE)
                {
                    player.up=2;
                    sec_jump=1;
                    saut(&player,dt,posinit,sec_jump,col_down);
                   
                    
                }
                else if(event.key.keysym.sym==SDLK_LCTRL)
                {
                    player.up=3;
                    sec_jump=1;
                    saut(&player,dt,posinit,sec_jump,col_down);
               
                }
                
            }
            break;
            
            default:
            {
                player.img.direction=4;
      
                                    
            }
            break;
       }
    }


        // Update game logic
        // Perso
    col_down=0;
          saut(&player,dt,posinit,sec_jump,col_down);

               
             
               dt=SDL_GetTicks()-t_prev;
       player.acceleration-=0.001;
       deplacerPerso (&player,dt,posinit); 
       player.up=0;      
       animerPerso (&player);
       //Perso


        deplacer(&enemy1, &enemy2);
        deplacerIA(&alien, player);
        animerEnnemi(&enemy1, &enemy2);
        animerboss(&alien);



        //COLLISIONS

        col_arrow=collision_arrow(player,alien);
if(col_arrow==1) 
    {
    if(alien.state!=WAITING && alien.state!=HIT && alien.state!=DIE)
    {
    player.pos.pos_Perso.y-=85;
    if(alien.direction_boss==0)
    player.pos.pos_Perso.x-=19;
    else player.pos.pos_Perso.x+=19;
  
    }
    }

collision=collisionBB(player,enemy1);
    if(collision==1)
    {
        if(player.pos.pos_Perso.y!=posinit && (player.pos.pos_Perso.y+player.pos.pos_Perso.h)<=enemy1.pos_eni.y+10 ) 
        {
     
            enemy1.die=1;

        }
         if(((player.pos.pos_Perso.y==enemy1.pos_eni.y+10) && (player.pos.pos_Perso.y==posinit) ) && (enemy1.die==0) && ((player.pos.pos_Perso.x+player.pos.pos_Perso.w)>enemy1.pos_eni.x) && (enemy1.direction==1)) 
    {
    player.pos.pos_Perso.x-=55;
   
    }

        else if(((player.pos.pos_Perso.y==enemy1.pos_eni.y+10) || (player.pos.pos_Perso.y==posinit) ) &&(enemy1.die==0) && (player.pos.pos_Perso.x<(enemy1.pos_eni.x+enemy1.pos_eni.w)) && (enemy1.direction==0 )) 
        {
        player.pos.pos_Perso.x+=55;
    }
}

     
     
  
collision2=collisionBB2(player,enemy2);
    if(collision2==1)
    {
        if(player.pos.pos_Perso.y!=posinit && (player.pos.pos_Perso.y+player.pos.pos_Perso.h)<enemy2.pos_eni2.y+10 && ((player.pos.pos_Perso.y)!=(enemy2.pos_eni2.y+enemy2.pos_eni2.h)) ) 
        {
            enemy2.die=1;
          
        }
         if((enemy2.die==0) &&(enemy2.direction==1)) 
        {
            player.pos.pos_Perso.x-=60;
        
           
        }
        else if((enemy2.die==0) && (enemy2.direction==0 ))
        {
             player.pos.pos_Perso.x+=60;
         
          
        }
    }

col_boss=collisionboss(player,alien);
if(col_boss==1) 
{
    if(alien.state!=DIE)
    {
        if(player.pos.pos_Perso.y!=posinit && (player.pos.pos_Perso.y+player.pos.pos_Perso.h)>=alien.pos_boss.y+21) 
        {
            alien.state=HIT;
            player.pos.pos_Perso.y-=40;
            alien.nb_hit++;
            if(!(alien.nb_hit%3))
            {
                if(alien.direction_boss==0)
                 player.pos.pos_Perso.x-=75;
                else if(alien.direction_boss==1) player.pos.pos_Perso.x+=75;
           
            }
            if(alien.nb_hit>=21)
            {
                alien.state=DIE;
            
            }
        }
        else
            {
                if(alien.direction_boss==0)
                 {
                    player.pos.pos_Perso.x-=55;
                 
                 }
                else if (alien.direction_boss==1)
                {
                 player.pos.pos_Perso.x+=55;
      
              
                }
            }
    }
}







        // Clear the screen
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));

        // Draw game objects
        afficherEnnemi(enemy1, enemy2, screen);
        afficherboss(alien, screen);
        afficherPerso(player, screen);

        // Update the screen
        SDL_Flip(screen);

        // Delay to control frame rate
        SDL_Delay(50);
    }
   


    // Clean up resources
    SDL_FreeSurface(screen);
    Mix_CloseAudio();
    SDL_Quit();

    return 0;
}
