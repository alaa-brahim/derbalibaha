#include "perso.h"
#include <stdio.h>   
#include <string.h>  

int main(int argc, char* argv[])
{   


     

SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO);
TTF_Init();
SDL_Surface *fenetre=NULL ,*resized_image;
fenetre=SDL_SetVideoMode(1280,720,32,SDL_HWSURFACE|SDL_DOUBLEBUF);

 SDL_Event event;
 
int continuer=1,winn=0;
    SDL_Surface *win;
    SDL_Surface *lost;
    SDL_Rect pos;
        pos.x=160;
        pos.y=330;


 
SDL_Surface *bg=IMG_Load("bg.png");
SDL_Surface *Life=IMG_Load("heart.png");
SDL_Rect heart1;
SDL_Rect heart2;
  heart1.x=1180;
  heart1.y=10;
  heart2.x=3;
  heart2.y=10;
SDL_Rect camera;
 
camera.x=0;
camera.y=0;
camera.w=2220;
camera.h=1080;
perso p2;
perso p;
p.OFFSET=0;
p2.OFFSET=0;
int ingame=0;
p.police=TTF_OpenFont("astro.ttf",20);

  p.positionTEXT.x=540;
  p.positionTEXT.y=30;
   init(&p);

    SDL_Color white;
white.r=255;
white.g=255;
white.b=255;
  p.police=TTF_OpenFont("astro.ttf",20);
p.text0=TTF_RenderText_Blended(p.police,"SCORE:0",white);
p.text1=TTF_RenderText_Blended(p.police,"SCORE:300",white);
p.text2=TTF_RenderText_Blended(p.police,"SCORE:600",white);
p.text3=TTF_RenderText_Blended(p.police,"SCORE:900",white);
  p.positionTEXT.x=50;
  p.positionTEXT.y=150;
 SDL_Surface *chrono;
    char timeText[100];



  
while(1){
                               
    if (p.EXIT==1)
    return 0;      


     


   
     if ((((p.posSCREEN.x<=700)&&(p.ALIVE==1)) || ((p2.posSCREEN.x<=700)&&(p2.ALIVE==1)&&(p.plusPLAYER==2))) && (camera.x>0))
  {
   if (p.plusPLAYER==2)
   {
      p2.posSCREEN.x+=4;
      p2.OFFSET+=4;

   }
   p.OFFSET+=4;
   p.posSCREEN.x+=4;
   camera.x-=4;
  }
   if ((((p.posSCREEN.x>=1300)&&(p.ALIVE==1)) || ((p2.posSCREEN.x>=1300)&&(p2.ALIVE==1)&&(p.plusPLAYER==2))) && (camera.x<300))
  {
   if (p.plusPLAYER==2)
   {
      p2.posSCREEN.x-=4;
      p2.OFFSET-=4;
   }

   p.OFFSET-=4;
   p.posSCREEN.x-=4;
   camera.x+=4;
  }
  
  


     if (p.plusPLAYER==2)
    {
      



       moveperso2(&p,&p2);
       
    }
      

    else
    {


          moveperso(&p);
        

        }
   



     



        



     SDL_BlitSurface(bg,NULL,fenetre,NULL);



    if (p.plusPLAYER==2)
     {
      if (p2.ALIVE==1)
      {
     afficherperso(&p2,fenetre);
     SDL_BlitSurface(Life,NULL,fenetre,&heart1);
      }
     }

    if (p.ALIVE==1)
    {
    afficherperso(&p,fenetre);
    SDL_BlitSurface(Life,NULL,fenetre,&heart2);
    }
 
     if ((p.ALIVE==0)&&(p.plusPLAYER==1))
     {
      initperso (&p);
      p.OFFSET=0;
      camera.x=0;
      camera.y=0;
     }
      else 
      {
         if((p.ALIVE==0)&&(p2.ALIVE==0)&&(p.plusPLAYER==2))
         {
            initperso (&p);
            initperso (&p2);
              p2.sprite=IMG_Load("Sprite2.png");
            p.OFFSET=0;
            p2.OFFSET=0;
            camera.x=0;
            camera.y=0;

         }
      }
  sprintf(timeText,"%d", SDL_GetTicks());
        chrono=TTF_RenderText_Blended(p.police,timeText,white);
        SDL_BlitSurface(chrono, NULL,fenetre,&p.positionTEXT);
            
            SDL_Flip(fenetre);


      
    }
    
  





SDL_FreeSurface(fenetre);

SDL_Quit();

return 0;

  }

