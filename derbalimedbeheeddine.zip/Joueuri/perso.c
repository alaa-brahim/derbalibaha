#include "perso.h"
void init (perso *p)
{
	do
	{ 
	printf("Enter Number of players");
	scanf("%d",&(p->plusPLAYER));
}while(!(p->plusPLAYER==1 || p->plusPLAYER==2));
  }
void initperso (perso *p)
{
	p->ground=500;
    p->ALIVE=1;
	p->right=0;p->left=0;p->up=0;p->ymax=350;p->i=0;p->acceleration=5,p->dash=0,p->anim=0,p->numberjump=0;
    p->posSPRITE.x=0;
    p->posSPRITE.y=0;
    p->posSPRITE.w=354/4;
    p->posSPRITE.h=501/4;
    p->posSCREEN.y=450;
     p->posSCREEN.x=40;  
	
	p->sprite=IMG_Load("sprite.png");
	p->direction=0;
    p->EXIT=0;
}
void moveperso(perso *p)
{   
	    while(SDL_PollEvent(&(p->event)))
    {   
  switch(p->event.type){
    case SDL_KEYDOWN:
      if((p->event.key.keysym.sym==SDLK_LEFT) && (p->CLEFT==0))
        p->left=1;
      if(p->event.key.keysym.sym==SDLK_p)
     
        {
        p->plusPLAYER=2;
        }
       if(p->event.key.keysym.sym==SDLK_u)
     {
        p->ALIVE=0;

     }

       
      if((p->event.key.keysym.sym==SDLK_RIGHT) && (p->CRIGHT==0))
        p->right=1;
       if((p->event.key.keysym.sym==SDLK_UP)&&(p->posSCREEN.y>p->ymax))
             	{  
       	          if (p->numberjump<2)
       	          	{ 

       	          	 p->ymax=p->posSCREEN.y-150;
                     p->up=1;
                       	}
               
                 }
        
    if(p->event.key.keysym.sym==SDLK_ESCAPE)
        {
       
         p->EXIT=1;
        }
    if(p->event.key.keysym.sym==SDLK_LSHIFT && (p->left==1 || p->right==1))
    {
      p->dash=1;
    }
        break;
    
    case SDL_KEYUP:
          if(p->event.key.keysym.sym==SDLK_LEFT)
            { 
        p->left=0;
        p->acceleration=3;
        
        }

       
      if(p->event.key.keysym.sym==SDLK_RIGHT)
        { 
        p->right=0;
        p->acceleration=3;
        }
  
       if(p->event.key.keysym.sym==SDLK_UP)
        
        p->numberjump++;
           break;
        
        }
        }
        if (p->posSCREEN.y<=p->ymax)
          p->up=0;





     if (!(p->left==1 && p->right==1))
     	{ 

        if (p->left==1)
        { 
         p->posSCREEN.x-=p->acceleration;
         if (p->acceleration<7)
         p->acceleration+=0.15;

         if( p->dash==1)
         { 
         	p->ddash=1;
         }

            
         }
        if (p->right==1)
            {
         p->posSCREEN.x+=p->acceleration;
         if (p->acceleration<7)
         	
         p->acceleration+=0.15;

           if( p->dash==1)
         { 
         	p->ddash=2;

         }
          }
          }
        if (p->up==0)
        {
            p->ymax=p->posSCREEN.y-150;
            
          if (p->posSCREEN.y<p->ground && p->dash==0)
            {


            	if ((p->CRIGHT==1) || (p->CLEFT==1))
            	{
            		p->posSCREEN.y+=1.5;
            		p->numberjump=0;
            	}
            	else
                p->posSCREEN.y+=7.5;
            }
            if (p->posSCREEN.y>=p->ground)
            	p->numberjump=0;

        }
        else if ((p->up==1)&&(p->posSCREEN.y>p->ymax))
        {
            p->posSCREEN.y-=7;


        }
        if (p->ddash==1)
   {
   	if (p->i<10)
            { 
                p->posSCREEN.x-=15;
                p->i++;
            }
            else
            {
                p->dash=0;
                p->ddash=0;
                p->i=0;
            }

   }
        	else
        	{


        		if (p->ddash==2)
        		{
        			if (p->i<10)
            { 
                p->posSCREEN.x+=15;
                p->i++;
            }
            else
            {
                p->dash=0;
                p->ddash=0;
                p->i=0;
            }

        		}
        	}
  



	
}

void afficherperso(perso *p,SDL_Surface *fenetre)
{
	
        SDL_BlitSurface(p->sprite,&(p->posSPRITE),fenetre,&(p->posSCREEN));

         if (p->anim==5 || p->anim==10 || p->anim==15)
        {
           animation(p);
           if (p->anim==15)
           	p->anim=0;
        }
       
        p->anim++;
}
void animation(perso *p)
{

    if (!((p->right==0&&p->left==0)||(p->right==1&&p->left==1)))
    {
    	if (p->right==1 && p->up==0)
    		p->direction=0;
        else
        {
        	if (p->left==1 && p->up==0)
        	p->direction=1;
        
            else
            {
            	if (p->right==1 && p->up==1)
            		p->direction=2;
            	else
            	{
            		if(p->left==1 && p->up==1)
            			 p->direction=3;
            	}
            }


        }

	p->posSPRITE.y=p->direction * p->posSPRITE.h;
	p->posSPRITE.x=p->posSPRITE.x+p->posSPRITE.w;
	if ( p->up==1)
	p->posSPRITE.x=0;
	else
		{ 
	if (p->posSPRITE.x>=(354-p->posSPRITE.w))
		p->posSPRITE.x=0;
	 }
	 }

	else
		p->posSPRITE.x=0;
}

void moveperso2(perso *p,perso *p2)
{
	 while(SDL_PollEvent(&(p->event)))
    {   
  switch(p->event.type){
    case SDL_KEYDOWN:
      if(p->event.key.keysym.sym==SDLK_LEFT)
        p->left=1;
      if(p->event.key.keysym.sym==SDLK_a)
        p2->left=1;

       
      if(p->event.key.keysym.sym==SDLK_RIGHT)
        p->right=1;

       if((p->event.key.keysym.sym==SDLK_UP)&&(p->posSCREEN.y>p->ymax))
             	{  
       	          if (p->numberjump<2)

                   p->up=1;
                 }
           
      if(p->event.key.keysym.sym==SDLK_d)
        p2->right=1;

       if((p->event.key.keysym.sym==SDLK_w)&&(p2->posSCREEN.y>p2->ymax))
             	{  
       	          if (p2->numberjump<2)

                   p2->up=1;
                 }
        
    if(p->event.key.keysym.sym==SDLK_ESCAPE)
        {  
        SDL_Quit();
        }
    if(p->event.key.keysym.sym==SDLK_u)
     {
        p->ALIVE=0;

     }
     if(p->event.key.keysym.sym==SDLK_i)
     {
        p2->ALIVE=0;

     }
    if(p->event.key.keysym.sym==SDLK_LSHIFT && (p->left==1 || p->right==1))
    {
      p->dash=1;
    }
     if(p->event.key.keysym.sym==SDLK_LSHIFT && (p2->left==1 || p2->right==1))
    {
      p2->dash=1;
    }
        break;
    
    case SDL_KEYUP:
          if(p->event.key.keysym.sym==SDLK_LEFT)
            { 
        p->left=0;
        
        p->acceleration=3;
        }

       
      if(p->event.key.keysym.sym==SDLK_RIGHT)
        { 
        p->right=0;
        p->acceleration=3;
        }
  
       if(p->event.key.keysym.sym==SDLK_UP)
       {
      
        p->numberjump++;
        }
           if(p->event.key.keysym.sym==SDLK_a)
            { 
        p2->left=0;
        p2->acceleration=3;
        }

       
      if(p->event.key.keysym.sym==SDLK_d)
        { 
        p2->right=0;
        p2->acceleration=3;
        }
  
       if(p->event.key.keysym.sym==SDLK_w)
       {
        
        p2->numberjump++;
        }

           break;
        
        }
        }
        if (p->posSCREEN.y<=p->ymax)
          p->up=0;

     if (!(p->left==1 && p->right==1))
     	{ 

        if (p->left==1)
        { 
         p->posSCREEN.x-=p->acceleration;
         if (p->acceleration<7)
         p->acceleration+=0.15;

         if( p->dash==1)
         { 
         	p->ddash=1;
         }

            
         }
        if (p->right==1)
        	
            {
         p->posSCREEN.x+=p->acceleration;
         if (p->acceleration<7)
         	
         p->acceleration+=0.15;

           if( p->dash==1)
         { 
         	p->ddash=2;

         }
          }
          }
        if (p->up==0)
        {
            p->ymax=p->posSCREEN.y-150;
            
         if (p->posSCREEN.y<p->ground && p->dash==0)
            {


            	if ((p->CRIGHT==1) || (p->CLEFT==1))
            	{
            		p->posSCREEN.y+=1.5;
            		p->numberjump=0;
            	}
            	else
                p->posSCREEN.y+=7.5;
            }
            if (p->posSCREEN.y>=p->ground)
            	p->numberjump=0;

        }
        else if ((p->up==1)&&(p->posSCREEN.y>p->ymax))
        {
            p->posSCREEN.y-=7;


        }
                if (p->ddash==1)
   {
   	if (p->i<10)
            { 
                p->posSCREEN.x-=15;
                p->i++;
            }
            else
            {
                p->dash=0;
                p->ddash=0;
                p->i=0;
            }

   }
        	else
        	{


        		if (p->ddash==2)
        		{
        			if (p->i<10)
            { 
                p->posSCREEN.x+=15;
                p->i++;
            }
            else
            {
                p->dash=0;
                p->ddash=0;
                p->i=0;
            }

        		}
        	}



 





 

          if (p2->posSCREEN.y<=p2->ymax)
          p2->up=0;

     if (!(p2->left==1 && p2->right==1))
     	{ 

        if (p2->left==1)
        { 
         p2->posSCREEN.x-=p2->acceleration;
         if (p2->acceleration<7)
         p2->acceleration+=0.15;

         if( p2->dash==1)
         { 
         	p2->ddash=1;
         }

            
         }
        if (p2->right==1)
            {
         p2->posSCREEN.x+=p2->acceleration;
         if (p2->acceleration<7)
         	
         p2->acceleration+=0.15;

           if( p2->dash==1)
         { 
         	p2->ddash=2;

         }
          }
          }
        if (p2->up==0)
        {
            p2->ymax=p2->posSCREEN.y-150;
            
        if (p2->posSCREEN.y<p2->ground && p2->dash==0)
            {


            	if ((p2->CRIGHT==1) || (p2->CLEFT==1))
            	{
            		p2->posSCREEN.y+=1.5;
            		p2->numberjump=0;
            	}
            	else
                p2->posSCREEN.y+=7.5;
            }
            if (p2->posSCREEN.y>=p2->ground)
            	p2->numberjump=0;

        }
        else if ((p2->up==1)&&(p2->posSCREEN.y>p2->ymax))
        {
            p2->posSCREEN.y-=7;


        }
                if (p2->ddash==1)
   {
   	if (p2->i<10)
            { 
                p2->posSCREEN.x-=15;
                p2->i++;
            }
            else
            {
                p2->dash=0;
                p2->ddash=0;
                p2->i=0;
            }

   }
        	else
        	{


        		if (p2->ddash==2)
        		{
        			if (p2->i<10)
            { 
                p2->posSCREEN.x+=15;
                p2->i++;
            }
            else
            {
                p2->dash=0;
                p2->ddash=0;
                p2->i=0;
            }

        		}
        	}
	
}

void collision (perso *p)
{
	  p->CRIGHT=0;
	  p->CLEFT=0;

  if (p->posSCREEN.x+75>=2190+p->OFFSET)
  {
  	p->CRIGHT=1;
  	p->posSCREEN.x=2115+p->OFFSET;

  }



	if (p->posSCREEN.y>420) 
	{

		

		if ((p->posSCREEN.y<=560) && (p->posSCREEN.x<=1850+p->OFFSET))
			p->up=0;
		


		
		if ((p->posSCREEN.x<=630+p->OFFSET) && (95+p->OFFSET<=p->posSCREEN.x))
		{


			
			if (p->posSCREEN.y<=615)
			{



                       
				p->ground=615;
		    }
		    else
		    {
		    		if ((p->ground!=615) && (170+p->OFFSET<=p->posSCREEN.x+75) && (!(170+p->OFFSET<=p->posSCREEN.x)) )
		    	{
		    	     	p->CRIGHT=1;
						p->posSCREEN.x=95+p->OFFSET;

		    	}
		    	else
		    	{
		    				    	if ((p->ground!=615) && (p->posSCREEN.x<=630+p->OFFSET) && (!(630+p->OFFSET>=p->posSCREEN.x+75)) )
		    				    	{
		    				    		   	p->CLEFT=1;
			                            	p->posSCREEN.x=630+p->OFFSET;



		    				    	}

		    	}





		    }
		   //
		 }
			else
			{
				



				p->ground=725; 

			}

		





	}




	else

	{
		if (p->posSCREEN.y>=200)
		{
			if (p->posSCREEN.x<=1850+p->OFFSET)
			{
				p->ground=412;
			}
			else
				p->ground=725;
			if ((p->posSCREEN.y<=308) && (p->posSCREEN.x>=280+p->OFFSET))
				p->up=0;
			if (( p->posSCREEN.x <=30+p->OFFSET) && (p->ground==412))
			{
				p->CLEFT=1;
				p->posSCREEN.x=30+p->OFFSET;
			}



		}
		   else
		   {
		   	   if (p->posSCREEN.x>=280+p->OFFSET)

		   	   	p->ground=160;
		   	   else 
		   	   p->ground=412;

		   	   if (p->posSCREEN.y<=23)
		   	   	p->up=0;
		   	    






		   }










	}






}
