#include <stdio.h>
#include <SDL/SDL.h>
#include <stdlib.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_events.h>
#include <SDL/SDL_image.h>

typedef struct 
{
	int right,left,up,ymax,dash,ddash,i,numberjump,direction,anim,ground,ALIVE;
	
	int CRIGHT,CLEFT,CUP,OFFSET;
	float acceleration;
	SDL_Rect posSPRITE;
	SDL_Rect posSCREEN;
	SDL_Surface *sprite;
	SDL_Surface *Life;
	SDL_Event event;
	SDL_Rect heart;
	TTF_Font *police;
	SDL_Surface *text0;
	SDL_Surface *text1;
	SDL_Surface *text2;
	SDL_Surface *text3;
	SDL_Rect positionTEXT;
	int plusPLAYER;
	int EXIT;
}perso;

void init (perso *p);
void initperso (perso *p);
void moveperso(perso *p);
void moveperso2(perso *p,perso *p2);
void afficherperso(perso *p,SDL_Surface *fenetre);
void animation(perso *p);
void collision (perso *p);
